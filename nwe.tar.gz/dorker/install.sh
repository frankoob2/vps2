apt install firefox
pip3 install -r requirements.txt
wget https://github.com/mozilla/geckodriver/releases/download/v0.29.1/geckodriver-v0.29.1-linux64.tar.gz
chmod +x geckodriver-v0.29.1-linux64.tar.gz
sudo cp geckodriver-v0.29.1-linux64.tar.gz /usr/local/bin/geckodriver
